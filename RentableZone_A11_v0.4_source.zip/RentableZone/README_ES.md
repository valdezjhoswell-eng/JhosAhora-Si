# RentableZone v0.4 — visor/análisis visual para Galaxy Tab A11

RentableZone es un visor personal de ofertas de Uber y Cabify. **No acepta, rechaza, pulsa botones ni modifica esas aplicaciones.** Android autoriza la captura de pantalla y ML Kit analiza visualmente el contenido.

## Regla fundamental de cálculo

- Distancia total = **distancia hasta recogida + distancia del viaje**.
- Tiempo total = **tiempo hasta recogida + tiempo del viaje**.
- **Nunca se suma ni se estima el regreso.**
- $/km = importe / distancia total.
- $/hora = importe / tiempo total × 60.

## Datos que intenta reconocer

Importe, recogida, viaje, tiempos, origen, destino, viajes/calificación del pasajero cuando estén visibles, estado de pago Cabify, efectivo, peajes y el indicador $/km de Cabify cuando aparezca.

El OCR depende del formato que muestre cada aplicación. Se recomienda probar capturas reales y ajustar patrones si Uber/Cabify cambian su interfaz.

## Resultado

El análisis puede ser:

- 🟢 CONVIENE
- 🟡 EVALUAR
- 🔴 NO CONVIENE

La zona se muestra aparte como permitida, precaución, peligrosa o no determinada. **RentableZone no decide automáticamente qué zona es peligrosa: los polígonos los define el usuario.**

## Filtros

- ganancia mínima $/km;
- ganancia mínima $/hora;
- distancia máxima;
- tiempo máximo;
- viajes mínimos del pasajero;
- tratamiento informativo del efectivo Cabify;
- costo operativo por km y visualización opcional de ganancia neta;
- transparencia, tamaño y posición del visor;
- mostrar/ocultar visor.

El tratamiento "NO CONVIENE" del efectivo es únicamente un resultado informativo: **no ejecuta ninguna acción en Cabify**.

## Mapa de zonas

El usuario puede dibujar polígonos manualmente:

- 🟢 verde = permitida;
- 🟡 amarilla = precaución;
- 🔴 roja = peligrosa.

El destino OCR se geocodifica para consultar esos polígonos. Si hay polígonos superpuestos, roja tiene prioridad sobre amarilla y verde.

El mapa utiliza Google Maps y requiere una API key configurada en `app/build.gradle.kts` mediante `MAPS_API_KEY`.

## Compilación

Abrir el proyecto en Android Studio, sincronizar Gradle y ejecutar `Build > Build APK(s)`.

La aplicación usa Java/Kotlin 17, compileSdk 35 y targetSdk 35.

## Permisos

1. Permiso de "Mostrar sobre otras aplicaciones".
2. Al iniciar el visor, aceptar la autorización de Android para captura de pantalla.
3. Mantener el servicio en primer plano mientras se analiza la pantalla.
