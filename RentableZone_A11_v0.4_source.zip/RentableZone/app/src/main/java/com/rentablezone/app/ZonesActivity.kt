package com.rentablezone.app

import android.graphics.Color
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Polygon
import com.google.android.gms.maps.model.PolygonOptions

class ZonesActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var map: GoogleMap
    private lateinit var mapView: MapView
    private val points = mutableListOf<LatLng>()
    private var currentPolygon: Polygon? = null
    private val zones = mutableListOf<SavedZone>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zones)

        zones.addAll(ZoneStore.load(this))
        mapView = findViewById(R.id.map)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)

        val spinner = findViewById<Spinner>(R.id.spZone)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("🟢 Permitida", "🟡 Precaución", "🔴 Peligrosa")
        )
        spinner.setSelection(0)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            if (points.size < 3) {
                toast("Marca al menos 3 puntos")
                return@setOnClickListener
            }
            zones += SavedZone(spinner.selectedItemPosition, points.toList())
            ZoneStore.save(this, zones)
            toast("Zona guardada")
            points.clear()
            currentPolygon?.remove()
            currentPolygon = null
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            points.clear()
            currentPolygon?.remove()
            currentPolygon = null
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isZoomControlsEnabled = true
        map.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(-34.6037, -58.3816),
                11.5f
            )
        )
        map.setOnMapClickListener { latLng ->
            points += latLng
            redrawCurrent()
        }
        drawSavedZones()
    }

    private fun drawSavedZones() {
        zones.forEach { zone ->
            if (zone.points.size >= 3) {
                addPolygon(zone.points, zone.type, 4f, 50)
            }
        }
    }

    private fun redrawCurrent() {
        currentPolygon?.remove()
        if (points.size < 3) return
        val spinner = findViewById<Spinner>(R.id.spZone)
        currentPolygon = addPolygon(points, spinner.selectedItemPosition, 5f, 60)
    }

    private fun addPolygon(
        polygonPoints: List<LatLng>,
        type: Int,
        strokeWidth: Float,
        fillAlpha: Int
    ): Polygon {
        val c = zoneColor(type)
        return map.addPolygon(
            PolygonOptions()
                .addAll(polygonPoints)
                .strokeColor(c)
                .strokeWidth(strokeWidth)
                .fillColor(Color.argb(fillAlpha, Color.red(c), Color.green(c), Color.blue(c)))
        )
    }

    private fun zoneColor(type: Int): Int = when (type) {
        0 -> Color.rgb(30, 170, 90)
        1 -> Color.rgb(220, 160, 20)
        else -> Color.rgb(210, 55, 70)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapView.onDestroy()
        super.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }
}
